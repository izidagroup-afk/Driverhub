import React, {useState, useEffect} from 'react';
import axios from 'axios';
const API = (import.meta.env.VITE_API_URL || 'http://localhost:4000') + '/api';

export default function DriversPage({onBack}){
  const [drivers, setDrivers] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({name:'', age:'', experience:'', categories:'', languages:'', location:'', rating:'', description:''});
  const [photoFile, setPhotoFile] = useState(null);

  useEffect(()=>{ fetchDrivers(); },[]);

  function fetchDrivers(){
    axios.get(API + '/drivers').then(r=>setDrivers(r.data)).catch(()=>{});
  }

  function handleAdd(e){
    e.preventDefault();
    const fd = new FormData();
    Object.keys(form).forEach(k=>fd.append(k, form[k]));
    if(photoFile) fd.append('photo', photoFile);
    axios.post(API + '/drivers', fd, { headers: {'Content-Type':'multipart/form-data'} })
      .then(()=>{ setShowForm(false); setForm({name:'', age:'', experience:'', categories:'', languages:'', location:'', rating:'', description:''}); setPhotoFile(null); fetchDrivers(); })
      .catch(()=>{});
  }

  return (
    <div>
      <button className="link" onClick={onBack}>← Back</button>
      <h2>Drivers</h2>
      <button onClick={()=>setShowForm(!showForm)} className="primary">{showForm? 'Cancel':'Add driver'}</button>
      {showForm && (
        <form className="card form" onSubmit={handleAdd}>
          <input placeholder="Name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} required />
          <input placeholder="Age" value={form.age} onChange={e=>setForm({...form, age:e.target.value})} />
          <input placeholder="Experience (years)" value={form.experience} onChange={e=>setForm({...form, experience:e.target.value})} />
          <input placeholder="Categories (comma separated, e.g. B,C)" value={form.categories} onChange={e=>setForm({...form, categories:e.target.value})} />
          <input placeholder="Languages (comma separated, e.g. en,ru)" value={form.languages} onChange={e=>setForm({...form, languages:e.target.value})} />
          <input placeholder="Location (city)" value={form.location} onChange={e=>setForm({...form, location:e.target.value})} />
          <input placeholder="Rating" value={form.rating} onChange={e=>setForm({...form, rating:e.target.value})} />
          <textarea placeholder="Description" value={form.description} onChange={e=>setForm({...form, description:e.target.value})} />
          <input type="file" accept="image/*" onChange={e=>setPhotoFile(e.target.files[0])} />
          <button className="primary" type="submit">Create</button>
        </form>
      )}
      <div className="grid">
        {drivers.map(d=>(
          <div className="card" key={d.id}>
            <div className="card-row">
              <img src={d.photo || '/assets/logo.png'} className="avatar" alt="photo" />
              <div>
                <h3>{d.name}</h3>
                <p className="muted">{d.age} years • {d.experience} yrs exp</p>
                <p>{d.description}</p>
                <p className="muted">Categories: {d.categories.join(', ')} • Languages: {d.languages.join(', ')}</p>
                <p className="muted">Location: {d.location} • Rating: {d.rating}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
