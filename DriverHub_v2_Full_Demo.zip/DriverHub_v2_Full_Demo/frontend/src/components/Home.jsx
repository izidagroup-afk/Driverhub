import React from 'react';
export default function Home({onSelect}){
  return (
    <div className="home">
      <h1>Welcome to DriverHub</h1>
      <div className="big-buttons">
        <div className="big-btn" onClick={()=>onSelect('drivers')}>Drivers</div>
        <div className="big-btn" onClick={()=>onSelect('companies')}>Companies</div>
      </div>
    </div>
  )
}
