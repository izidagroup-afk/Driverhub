import React, {useState, useEffect} from 'react';
import axios from 'axios';
const API = (import.meta.env.VITE_API_URL || 'http://localhost:4000') + '/api';

export default function CompaniesPage({onBack}){
  const [companies, setCompanies] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({name:'', city:'', description:'', open_vacancies:1});

  useEffect(()=>{ fetchCompanies(); },[]);

  function fetchCompanies(){
    axios.get(API + '/companies').then(r=>setCompanies(r.data)).catch(()=>{});
  }

  function handleAdd(e){
    e.preventDefault();
    axios.post(API + '/companies', form).then(()=>{ setShowForm(false); setForm({name:'', city:'', description:'', open_vacancies:1}); fetchCompanies(); }).catch(()=>{});
  }

  return (
    <div>
      <button className="link" onClick={onBack}>← Back</button>
      <h2>Companies</h2>
      <button onClick={()=>setShowForm(!showForm)} className="primary">{showForm? 'Cancel':'Add company'}</button>
      {showForm && (
        <form className="card form" onSubmit={handleAdd}>
          <input placeholder="Company name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} required />
          <input placeholder="City" value={form.city} onChange={e=>setForm({...form, city:e.target.value})} />
          <input placeholder="Open vacancies" type="number" value={form.open_vacancies} onChange={e=>setForm({...form, open_vacancies:parseInt(e.target.value)})} />
          <textarea placeholder="Description" value={form.description} onChange={e=>setForm({...form, description:e.target.value})} />
          <button className="primary" type="submit">Create</button>
        </form>
      )}
      <div className="grid">
        {companies.map(c=>(
          <div className="card" key={c.id}>
            <h3>{c.name}</h3>
            <p className="muted">{c.city}</p>
            <p>{c.description}</p>
            <p className="muted">Open vacancies: {c.open_vacancies}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
