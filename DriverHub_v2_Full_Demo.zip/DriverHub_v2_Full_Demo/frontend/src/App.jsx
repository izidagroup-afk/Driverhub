import React, {useState} from 'react';
import Home from './components/Home';
import DriversPage from './components/DriversPage';
import CompaniesPage from './components/CompaniesPage';

export default function App(){
  const [route, setRoute] = useState('home');

  function navigate(to){ setRoute(to); window.scrollTo(0,0); }

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <img src="/assets/logo.png" alt="logo" className="logo" />
          <div className="slogan">DriverHub — Connecting Drivers and Companies</div>
        </div>
      </header>
      <main className="container">
        {route==='home' && <Home onSelect={navigate} />}
        {route==='drivers' && <DriversPage onBack={()=>navigate('home')} />}
        {route==='companies' && <CompaniesPage onBack={()=>navigate('home')} />}
      </main>
      <footer className="footer">Demo • DriverHub</footer>
    </div>
  );
}
