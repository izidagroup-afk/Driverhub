DriverHub Demo v2 (Docker)
==========================

This archive contains DriverHub Demo v2 with frontend and backend and Docker configuration.

How to run with Docker:
1. unzip DriverHub_v2_Full_Demo.zip
2. cd DriverHub_v2_Full_Demo
3. docker-compose up --build
4. Open http://localhost:3000

API:
- GET /api/drivers
- POST /api/drivers (multipart/form-data; field 'photo' for image)
- GET /api/companies
- POST /api/companies

Notes:
- Uploaded photos are stored in backend/uploads and served at /uploads/<filename>
