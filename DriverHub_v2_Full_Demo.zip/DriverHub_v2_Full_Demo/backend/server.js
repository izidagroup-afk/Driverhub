const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const DATA_DIR = path.join(__dirname, 'data');
const DRIVERS_FILE = path.join(DATA_DIR, 'drivers.json');
const COMPANIES_FILE = path.join(DATA_DIR, 'companies.json');

function readJSON(file, defaultVal){ try { return JSON.parse(fs.readFileSync(file,'utf8')); } catch(e){ return defaultVal; } }
function writeJSON(file, data){ fs.writeFileSync(file, JSON.stringify(data,null,2)); }

if(!fs.existsSync(DRIVERS_FILE)) writeJSON(DRIVERS_FILE, []);
if(!fs.existsSync(COMPANIES_FILE)) writeJSON(COMPANIES_FILE, []);

const storage = multer.diskStorage({
  destination: (req,file,cb)=>cb(null, path.join(__dirname,'uploads')),
  filename: (req,file,cb)=> cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

app.get('/api/drivers', (req,res)=>{
  const drivers = readJSON(DRIVERS_FILE, []);
  const q=(req.query.q||'').toLowerCase();
  const city=(req.query.city||'').toLowerCase();
  const category=(req.query.category||'').toLowerCase();
  const lang=(req.query.lang||'').toLowerCase();
  let out = drivers.filter(d=>{
    if(q && !(d.name.toLowerCase().includes(q) || (d.description && d.description.toLowerCase().includes(q)))) return false;
    if(city && d.location.toLowerCase() !== city) return false;
    if(category && !d.categories.map(c=>c.toLowerCase()).includes(category)) return false;
    if(lang && !d.languages.map(l=>l.toLowerCase()).includes(lang)) return false;
    return true;
  });
  res.json(out);
});

app.post('/api/drivers', upload.single('photo'), (req,res)=>{
  const drivers = readJSON(DRIVERS_FILE, []);
  const b = req.body || {};
  const photo = req.file ? '/uploads/' + req.file.filename : (b.photoUrl || '');
  const newDriver = {
    id: Date.now(),
    name: b.name||'Unnamed',
    age: parseInt(b.age)||null,
    experience: parseFloat(b.experience)||null,
    categories: b.categories ? b.categories.split(',').map(s=>s.trim()) : [],
    languages: b.languages ? b.languages.split(',').map(s=>s.trim()) : [],
    location: b.location||'',
    rating: parseFloat(b.rating)||0,
    description: b.description||'',
    photo: photo
  };
  drivers.push(newDriver);
  writeJSON(DRIVERS_FILE, drivers);
  res.status(201).json(newDriver);
});

app.get('/api/companies', (req,res)=>{
  const companies = readJSON(COMPANIES_FILE, []);
  const q=(req.query.q||'').toLowerCase();
  const city=(req.query.city||'').toLowerCase();
  let out = companies.filter(c=>{
    if(q && !(c.name.toLowerCase().includes(q) || (c.description && c.description.toLowerCase().includes(q)))) return false;
    if(city && c.city.toLowerCase() !== city) return false;
    return true;
  });
  res.json(out);
});

app.post('/api/companies', (req,res)=>{
  const companies = readJSON(COMPANIES_FILE, []);
  const b = req.body || {};
  const newCompany = {
    id: Date.now(),
    name: b.name||'Unnamed Co',
    city: b.city||'',
    description: b.description||'',
    open_vacancies: parseInt(b.open_vacancies)||0
  };
  companies.push(newCompany);
  writeJSON(COMPANIES_FILE, companies);
  res.status(201).json(newCompany);
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log('Backend running on http://localhost:' + PORT));
